﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Models
{
    public class Job
    {

        [Key]
        public int Id { get; set; }
        [ForeignKey("Department")]
        public int DepartmentId { get; set; }
        [ForeignKey("Location")]
        public int LocationId { get; set; }

        public string Title { get; set; }

        public DateTime OpeningDate { get; set; }
        public DateTime ClosingDate { get; set; }



        public string Description { get; set; }

        public virtual Department Department { get; set; }

        public virtual Location Location { get; set; }


    }
}
